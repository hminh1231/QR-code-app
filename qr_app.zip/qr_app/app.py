import streamlit as st 
import pandas as pd
import numpy as np
import qrcode
import cv2
from PIL import Image

# Tạo một session state để theo dõi trạng thái của trang
session_state = st.session_state

# Trang chính
if 'page' not in session_state:
    session_state.page = "Home"
st.header("QR Scan & Generate application")

# Menu chọn trang
page = st.selectbox("Select Pages:", ["Home", "Generate QR Code", "Extract QR Code"])

# Lưu trạng thái trang vào session state
session_state.page = page
# Trang chuyển đổi
if session_state.page == "Extract QR Code":
    st.title("Extract QR Information")
    picture = st.camera_input("Take a picture")

    if picture:
        st.image(picture)
        # Load image
        img = Image.open(picture)
        # To convert PIL Image to numpy array:
        img_array = np.array(img)
        # Detect and decode
        detector = cv2.QRCodeDetector()
        data, bbox, rectified_img = detector.detectAndDecode(img_array)
        st.text("Data extracted: ")
        try:
            name, project,dept = data.split("|")
        # Tạo DataFrame từ thông tin người dùng
        except:
            name = data
            project = data
            dept = data
        data = {'Name': [name], 'Project': [project], 'Department': [dept]}
        df_extract = pd.DataFrame(data)
        output = df_extract.to_excel('data_extracted.xlsx', index=False)
        st.write("Information have been extracted:")
        st.write(df_extract)
        
        with open('data_extracted.xlsx', 'rb') as file:
            file_data = file.read()
        
        st.download_button(
            label="Click here to download Excel",
            data=file_data,
            key="excel-download",
            file_name="data_extracted.xlsx",
        )

elif session_state.page == "Generate QR Code":
    st.title("Generate QR Code")

    # Tạo các widgets để nhập thông tin
    name = st.text_input("Input Name:")
    project = st.text_input("Input Project Name:")
    dept = st.text_input("Input Department:")

    # Khi người dùng nhấn nút "Lưu"
    if st.button("Save"):
        img_file = st.empty()
        # Format data string with delimiters
        data = f"{name}|{project}|{dept}"

        # Generate a QR code
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(data)
        qr.make(fit=True)

        # Create an image from the QR code
        qr_img = qr.make_image(fill_color="black", back_color="white")

        # Save the QR code as an image
        qr_img.save("product_qr.png")

        st.image('product_qr.png')
        
        
        # Tạo DataFrame từ thông tin người dùng
        data = {'Name': [name], 'Project': [project], 'Department': [dept]}
        df = pd.DataFrame(data)

        # Lưu vào tệp Excel
        output = df.to_excel('data.xlsx', index=False)
        

        # Hiển thị thông tin vừa lưu lên giao diện
        st.write("Information have been saved:")
        st.write(df)
        
        with open('data.xlsx', 'rb') as file:
            file_data = file.read()
        
        st.download_button(
            label="Click here to download Excel",
            data=file_data,
            key="excel-download",
            file_name="data.xlsx",
        )

